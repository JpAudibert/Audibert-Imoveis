<!-- Footer -->
<footer class="py-5 cor-audibert fixar-baixo">
    <div class="container">
        <p class="m-0 text-center text-white">Endereço: Rua Salgado Filho, 29, Centro, Carlos Barbosa. - Contato: (54) 3461-2025 - Plantão: (54) 99973-2414 - Email: contato@audibertimoveis.com.br.</p>
        <p class="m-0 text-center text-white">Copyright &copy; Audibert Corretora de Imóveis LTDA <script>document.write(new Date().getFullYear())</script> - CRECI 34.941</p>
    </div>
    <!-- /.container -->
</footer>
