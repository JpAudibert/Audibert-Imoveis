<?php
$a=0;
$c=0;
$co=0;
$r=0;
$t=0;
$all=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Administração</title>
</head>
<body>
    <div class="container">
        <?php echo $__env->make('layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row justify-content-center dashboard">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <div class="card-header mid-field">Inserir Imóveis</div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><a href="<?php echo e(url('/apartamento/inserir')); ?>">Apartamento</a></li>
                            <li class="list-group-item"><a href="<?php echo e(url('/casa/inserir')); ?>">Casa</a></li>
                            <li class="list-group-item"><a href="<?php echo e(url('/terreno/inserir')); ?>">Terreno</a></li>
                            <li class="list-group-item"><a href="<?php echo e(url('/rural/inserir')); ?>">Área Rural</a></li>
                            <li class="list-group-item"><a href="<?php echo e(url('/comercial/inserir')); ?>">Comercial</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <div class="card-header mid-field">Visualizar Imóveis</div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><a href="<?php echo e(url('/apartamento/visualizar')); ?>">Apartamento <?php $__currentLoopData = $imoveis->where("discriminator","=","apartamento"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $a++; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> - <?php echo e($a); ?></a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('/casa/visualizar')); ?>">Casa <?php $__currentLoopData = $imoveis->where("discriminator","=","casa"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $c++; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> - <?php echo e($c); ?></a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('/terreno/visualizar')); ?>">Terreno <?php $__currentLoopData = $imoveis->where("discriminator","=","terreno"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $t++; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> - <?php echo e($t); ?></a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('/rural/visualizar')); ?>">Área Rural <?php $__currentLoopData = $imoveis->where("discriminator","=","rural"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $r++; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> - <?php echo e($r); ?></a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('/comercial/visualizar')); ?>">Comercial <?php $__currentLoopData = $imoveis->where("discriminator","=","comercial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $co++; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> - <?php echo e($co); ?></a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('/visualizar')); ?>">Todos imóveis <?php $__currentLoopData = $imoveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $all++; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> - <?php echo e($all); ?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
    </html>
