
<html lang="en">

<head>
    <?php echo $__env->make('\layouts.site.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Mostrar Imóvel</title>
</head>
<body>
    <div class="container">
        <?php echo $__env->make('\layouts.site.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3"><?php echo e($imovel->titulo); ?>

        </h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(url('/')); ?>">Página inicial</a>
            </li>
            <li class="breadcrumb-item active">Mostrar Comercial</li>
        </ol>
        <!-- Content Row -->
        <div class="row">
            <div class="container">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <?php for($i = 1; $i < count($imovel->img); $i++): ?>
                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
                        <?php endfor; ?>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100 fit" src="/images/imovel<?php echo e($imovel->id); ?>/<?php echo e($imovel->img[0]); ?>">
                        </div>
                        <?php for($j = 1; $j < count($imovel->img); $j++): ?>
                        <div class="carousel-item">
                            <img class="d-block w-100 fit" src="/images/imovel<?php echo e($imovel->id); ?>/<?php echo e($imovel->img[$j]); ?>">
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <div class="listagem-imovel box">
                <div class="alinha-texto">
                    <i class="fas fa-map-pin"></i>&nbsp;&nbsp;Endereço: <?php echo e($imovel->endereco); ?>, <?php echo e($imovel->bairro); ?>, <?php echo e($imovel->cidade); ?>, <?php echo e($imovel->estado); ?> - <?php echo e($imovel->cep); ?>

                </div>
                <div class="alinha-texto">
                    <i class="fas fa-ruler-combined"></i>&nbsp;&nbsp;Área do Terreno: <?php echo e($imovel->areatt); ?> m² -
                    &nbsp;&nbsp;<i class="fas fa-money-bill-wave"></i> Valor: <?php echo e($imovel->valor); ?> -
                    <?php if($imovel->categoria=="1"): ?>
                    &nbsp;&nbsp;<i class="fas fa-store-alt"></i> Tipo: Sala Comercial
                    <?php else: ?>
                    &nbsp;&nbsp;<i class="fas fa-industry"></i> Tipo: Pavilhão Industrial
                    <?php endif; ?>
                </div>
            </div>
            <div class="dados">
                <h4 class="titulo-descricao">Descrição do imovel:</h4>
                <div class="descricao-site">
                    <p><?php echo e($imovel->obs); ?></p>
                    <br>
                </div>
            </div>

        </div>
    </div>
    <?php echo $__env->make('\layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('\layouts.site.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

</html>
