<!DOCTYPE html>
<html lang="en">

  <head>
    <?php echo $__env->make('\layouts.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Inserir Imóvel</title>
  </head>
  <body>
    <div class="container">
<?php echo $__env->make('\layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Heading/Breadcrumbs -->
<h1 class="mt-4 mb-3">Inserir Casa</small>
</h1>

<ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo e(route('home')); ?>">Admin</a>
        </li>
        <li class="breadcrumb-item active">Inserir Casa</li>
      </ol>
<!-- Content Row -->
<div class="row">
    <!-- Sidebar Column -->
    <div class="col-lg-3 mb-4">
        <div class="list-group">
            <a href="<?php echo e(url('apinserir')); ?>" class="list-group-item">Apartamento</a>
            <a href="<?php echo e(url('casainserir')); ?>" class="list-group-item active">Casa</a>
            <a href="<?php echo e(url('terrenoinserir')); ?>" class="list-group-item">Terreno</a>
            <a href="<?php echo e(url('ruralinserir')); ?>" class="list-group-item">Área Rural</a>
            <a href="<?php echo e(url('comercialinserir')); ?>" class="list-group-item">Salas/Pavilhões</a>
            <a href="<?php echo e(route('logout')); ?>" class="list-group-item">Sair</a>
        </div>
    </div>
    <!-- Content Column -->
    <div class="col-lg-9 mb-4">
        <form name="inserir_ter" id="inserir_ter" action="<?php echo e(route('store')); ?>" method="POST" multipart="form/data">
            <?php echo csrf_field(); ?>
            
            <input type="hidden" name="discriminator" id="discriminator" value="casa">
            

            <div class="container">
                <h3>Casa</h3>
                <?php echo $__env->make('\layouts.admin.inserir.1geral-inserir', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                

                <br><h5> Dados do Imóvel:</h5><br>
                    <div class="control-group form-group row">
                      <div class="controls col-md-6 mb-1">
                        <label for="areapv" class="form-label">Área da Casa:</label><br>
                        <input type="text" class="form-control" id="areapv" name="areapv" required data-validation-required-message="Insira a Área Privativa" placeholder="Área Total do Imóvel" onkeypress="if (!isNaN(String.fromCharCode(window.event.keyCode))) return true; else return false;">
                      </div>
                      <div class="controls col-md-6">
                        <label for="garagem" class="form-label">Vagas de Garagem:</label><br>
                        <select name="garagem" id="garagem" class="custom-select">
                          <option hidden="">Selecione:</option>
                          <option value="1">1 vagas</option>
                          <option value="2">2 vagas</option>
                          <option value="3">3 vagas</option>
                          <option value="4">4 vagas ou mais</option>
                        </select>
                      </div>
                    </div>

                    <div class="control-group form-group row">
                              <div class="controls col-md-6">
                            <label for="banheiros" class="form-label">Número de Banheiros:</label><br>
                            <select name="banheiros" id="banheiros" class="custom-select">
                              <option hidden="">Selecione:</option>
                              <option value="1">1 banheiro</option>
                              <option value="2">2 banheiros</option>
                              <option value="3">3 banheiros</option>
                              <option value="4">4 banheiros ou mais</option>
                            </select>
                          </div>
                      <div class="controls col-md-6">
                        <label for="quartos" class="form-label">Número de Quartos:</label><br>
                        <select name="quartos" id="quartos" class="custom-select">
                          <option hidden="">Selecione:</option>
                          <option value="1">1 quarto</option>
                          <option value="2">2 quartos</option>
                          <option value="3">3 quartos</option>
                          <option value="4">4 quartos ou mais</option>
                        </select>
                      </div>
                    </div>


                    <br><h5> Detalhes do Imóvel:</h5><br>
                    <div class="control-group form-group row">
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="jardim" name="jardim" value="t">
                          <label class="custom-control-label" for="jardim">Jardim</label>
                        </div>
                      </div>
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="churras" name="churras" value="t">
                          <label class="custom-control-label" for="churras">Churrasqueira</label>
                        </div>
                      </div>
                    </div>

                    <div class="control-group form-group row">
                      <div class="custom control custom checkbox mb-3 col-md-6">
                      <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="mob" name="mob" value="t">
                          <label class="custom-control-label" for="mob">Mobília</label>
                        </div>
                      </div>
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="agua" name="agua" value="t">
                          <label class="custom-control-label" for="agua">Água Quente</label>
                        </div>
                      </div>
                    </div>

                    <div class="control-group form-group row">
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="cerca" name="cerca" value="t">
                          <label class="custom-control-label" for="cerca">Cercado</label>
                        </div>
                      </div>
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="lava" name="lava" value="t">
                          <label class="custom-control-label" for="lava">Lavanderia</label>
                        </div>
                      </div>
                    </div>

                    <div class="control-group form-group row">
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="quiosque" name="quiosque" value="t">
                          <label class="custom-control-label" for="quiosque">Quiosque</label>
                        </div>
                      </div>
                    </div>

                

                <?php echo $__env->make('\layouts.admin.inserir.2geral-inserir', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <!-- /.row -->

            </div>
            <!-- /.container -->
                <?php echo $__env->make('\layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('\layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Contact form JavaScript -->
            <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->

          </body>

</html>
