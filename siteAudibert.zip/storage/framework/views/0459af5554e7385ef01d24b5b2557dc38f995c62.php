<!DOCTYPE html>
<html lang="en">

  <head>
    <?php echo $__env->make('layouts.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Alterar Imóvel</title>
  </head>
  <body>

        <!-- Navigation -->
        <div class="container">
        <?php echo $__env->make('layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Alterar Terreno</small>
          </h1>

          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo e(route('home')); ?>">Admin</a>
            </li>
            <li class="breadcrumb-item active">Alterar Terreno</li>
          </ol>
            <!-- Content Row -->
          <div class="row">
            <!-- Sidebar Column -->
            <div class="col-lg-3 mb-4">
              <div class="list-group">
                    <a href="<?php echo e(url('apartamento/inserir')); ?>" class="list-group-item">Apartamento</a>
                    <a href="<?php echo e(url('casa/inserir')); ?>" class="list-group-item">Casa</a>
                    <a href="<?php echo e(url('terreno/inserir')); ?>" class="list-group-item active">Terreno</a>
                    <a href="<?php echo e(url('rural/inserir')); ?>" class="list-group-item">Área Rural</a>
                    <a href="<?php echo e(url('comercial/inserir')); ?>" class="list-group-item">Salas/Pavilhões</a>
              </div>
            </div>
            <!-- Content Column -->
            <div class="col-lg-9 mb-4">
              <form name="imovel" id="imovel" action="<?php echo e(route('update', Illuminate\Support\Facades\Crypt::encryptString($id))); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h3>Terreno</h3>
            <?php echo $__env->make('layouts.admin.alterar.1geral-alterar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.admin.alterar.2geral-alterar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <!-- /.row -->

            </div>
            <!-- /.container -->

            <!-- Footer -->
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Contact form JavaScript -->
            <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->

          </body>

</html>
