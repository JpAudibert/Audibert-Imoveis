<!DOCTYPE html>
<html lang="en">

  <head>
    <?php echo $__env->make('layouts.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Alterar Imóvel</title>
  </head>
  <body>

        <!-- Navigation -->
        <div class="container">
        <?php echo $__env->make('layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Alterar Sala Comercial/Pavilhão</small>
          </h1>

          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.html">Admin</a>
            </li>
            <li class="breadcrumb-item active">Alterar Sala Comercial/Pavilhão</li>
          </ol>
            <!-- Content Row -->
          <div class="row">
            <!-- Sidebar Column -->
            <div class="col-lg-3 mb-4">
              <div class="list-group">
                    <a href="<?php echo e(url('apinserir')); ?>" class="list-group-item">Apartamento</a>
                    <a href="<?php echo e(url('casainserir')); ?>" class="list-group-item">Casa</a>
                    <a href="<?php echo e(url('terrenoinserir')); ?>" class="list-group-item">Terreno</a>
                    <a href="<?php echo e(url('ruralinserir')); ?>" class="list-group-item">Área Rural</a>
                    <a href="<?php echo e(url('comercialinserir')); ?>" class="list-group-item active">Salas/Pavilhões</a>
                    <a href="<?php echo e(route('logout')); ?>" class="list-group-item">Sair</a>
              </div>
            </div>
            <!-- Content Column -->
            <div class="col-lg-9 mb-4">
              <form name="imovel" id="imovel" action="<?php echo e(route('update')); ?>" method="POST" multipart="form/data">
                <?php echo csrf_field(); ?>
                <h3>Sala Comercial/Pavilhão</h3>
            <?php echo $__env->make('layouts.admin.alterar.1geral-alterar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            

            <br><h5> Dados do Imóvel:</h5><br>
                <div class="control-group form-group row">
                  <div class="controls col-md-6">
                    <label for="categoria" class="form-label">Categoria do Comércio:</label><br>
                    <select name="categoria" id="categoria" class="custom-select">
                      <option hidden="">Selecione:</option>
                      <option value="1" <?php if($imovel->categoria==1): ?> echo selected <?php endif; ?>>Sala Comercial</option>
                      <option value="2" <?php if($imovel->categoria==2): ?> echo selected <?php endif; ?>>Pavilhão Industrial</option>
                    </select>
                  </div>
                </div>

            

            <?php echo $__env->make('layouts.admin.alterar.2geral-alterar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <!-- /.row -->

            </div>
            <!-- /.container -->

            <!-- Footer -->
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Contact form JavaScript -->
            <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->

          </body>

</html>
