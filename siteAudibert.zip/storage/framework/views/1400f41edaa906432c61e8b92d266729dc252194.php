<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Apartamentos</title>
    <?php echo $__env->make('layouts.site.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <div class="container">
        <?php echo $__env->make('layouts.site.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br />
        <h1 class="mt-4 mb-3">Apartamentos</small>
        </h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(url('/')); ?>">Página Inicial</a>
            </li>
            <li class="breadcrumb-item active">Apartamentos</li>
        </ol>
        <div class="row">
            <?php $__currentLoopData = $aps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 portfolio-item">
                <div class="card h-100">
                    <a href="<?php echo e(url($ap['discriminator'].'/ver/mais', Illuminate\Support\Facades\Crypt::encryptString($ap['id']))); ?>"><img class="card-img-top tamanho-card" src="/images/imovel<?php echo e($ap->id); ?>/<?php echo e($ap->img[0]); ?>" alt=""></a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="<?php echo e(url($ap['discriminator'].'/ver/mais', Illuminate\Support\Facades\Crypt::encryptString($ap['id']))); ?>"><?php echo e($ap['titulo']); ?></a>
                        </h4>
                        <p class="card-text"><i class="fas fa-building"></i>&nbsp;&nbsp; Apartamento</p>
                        <p class="card-text"><i class="fas fa-ruler-combined"></i>&nbsp;&nbsp; <?php echo e($ap->areatt); ?> m²</p>
                        <p class="card-text"><i class="fas fa-bed"></i>&nbsp;&nbsp; <?php if($ap->quartos==1): ?> <?php echo e($ap->quartos); ?> quarto <?php else: ?> <?php echo e($ap->quartos); ?> quartos <?php endif; ?></p>
                        <p class="card-text"><i class="fas fa-car"></i>&nbsp;&nbsp; <?php if($ap->garagem==1): ?> <?php echo e($ap->garagem); ?> vaga <?php else: ?> <?php echo e($ap->garagem); ?> vagas <?php endif; ?></p>
                        <p class="card-text"><i class="fas fa-toilet-paper"></i>&nbsp;&nbsp; <?php if($ap->banheiros==1): ?> <?php echo e($ap->banheiros); ?> banheiro <?php else: ?> <?php echo e($ap->banheiros); ?> banheiros <?php endif; ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="centro">
                <?php echo e($aps->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.site.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
