<!DOCTYPE html>
<html lang="en">

  <head>
    <?php echo $__env->make('layouts.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Alterar Imóvel</title>
  </head>
  <body>

        <!-- Navigation -->
        <div class="container">
        <?php echo $__env->make('layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Alterar Casa</small>
          </h1>

          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="<?php echo e(route('home')); ?>">Admin</a>
            </li>
            <li class="breadcrumb-item active">Alterar Casa</li>
          </ol>
            <!-- Content Row -->
          <div class="row">
            <!-- Sidebar Column -->
            <div class="col-lg-3 mb-4">
                <div class="list-group">
                    <a href="<?php echo e(url('apartamento/inserir')); ?>" class="list-group-item">Apartamento</a>
                    <a href="<?php echo e(url('casa/inserir')); ?>" class="list-group-item active">Casa</a>
                    <a href="<?php echo e(url('terreno/inserir')); ?>" class="list-group-item">Terreno</a>
                    <a href="<?php echo e(url('rural/inserir')); ?>" class="list-group-item">Área Rural</a>
                    <a href="<?php echo e(url('comercial/inserir')); ?>" class="list-group-item">Salas/Pavilhões</a>
                </div>
            </div>
            <!-- Content Column -->
            <div class="col-lg-9 mb-4">
              <form name="imovel" id="imovel" action="<?php echo e(route('update', Illuminate\Support\Facades\Crypt::encryptString($id))); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h3>Casa</h3>
            <?php echo $__env->make('layouts.admin.alterar.1geral-alterar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                

                <br><h5> Dados do Imóvel:</h5><br>
                    <div class="control-group form-group row">
                      <div class="controls col-md-6 mb-1">
                        <label for="areapv" class="form-label">Área da Casa:</label><br>
                      <input type="text" class="form-control" id="areapv" name="areapv" placeholder="Área da Casa" onkeypress="if (!isNaN(String.fromCharCode(window.event.keyCode))) return true; else return false;" value="<?php echo e($imovel->areapv); ?>">
                      </div>
                      <div class="controls col-md-6">
                        <label for="garagem" class="form-label">Vagas de Garagem:</label><br>
                        <select name="garagem" id="garagem" class="custom-select">
                          <option hidden="">Selecione:</option>
                          <option value="1" <?php if($imovel->garagem==1): ?> echo selected <?php endif; ?>>1 vagas</option>
                          <option value="2" <?php if($imovel->garagem==2): ?> echo selected <?php endif; ?>>2 vagas</option>
                          <option value="3" <?php if($imovel->garagem==3): ?> echo selected <?php endif; ?>>3 vagas</option>
                          <option value="4" <?php if($imovel->garagem==4): ?> echo selected <?php endif; ?>>4 vagas ou mais</option>
                        </select>
                      </div>
                    </div>

                    <div class="control-group form-group row">
                    <div class="controls col-md-6">
                        <label for="banheiros" class="form-label">Número de Banheiros:</label><br>
                        <select name="banheiros" id="banheiros" class="custom-select">
                          <option hidden="">Selecione:</option>
                          <option value="1" <?php if($imovel->banheiros==1): ?> echo selected <?php endif; ?>>1 banheiro</option>
                          <option value="2" <?php if($imovel->banheiros==2): ?> echo selected <?php endif; ?>>2 banheiros</option>
                          <option value="3" <?php if($imovel->banheiros==3): ?> echo selected <?php endif; ?>>3 banheiros</option>
                          <option value="4" <?php if($imovel->banheiros==4): ?> echo selected <?php endif; ?>>4 banheiros ou mais</option>
                        </select>
                      </div>
                      <div class="controls col-md-6">
                        <label for="quartos" class="form-label">Número de Quartos:</label><br>
                        <select name="quartos" id="quartos" class="custom-select">
                          <option hidden="">Selecione:</option>
                          <option value="1" <?php if($imovel->quartos==1): ?> echo selected <?php endif; ?>>1 quarto</option>
                          <option value="2" <?php if($imovel->quartos==2): ?> echo selected <?php endif; ?>>2 quartos</option>
                          <option value="3" <?php if($imovel->quartos==3): ?> echo selected <?php endif; ?>>3 quartos</option>
                          <option value="4" <?php if($imovel->quartos==4): ?> echo selected <?php endif; ?>>4 quartos ou mais</option>
                        </select>
                      </div>
                    </div>
                </div>
                    </div>
                    <br><h5> Detalhes do Imóvel:</h5><br>
                    <div class="control-group form-group row">
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="jardim" name="jardim" value="t" <?php if($imovel->jardim==true): ?> echo checked=""<?php endif; ?> >
                          <label class="custom-control-label" for="jardim">Jardim</label>
                        </div>
                      </div>
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="churras" name="churras" value="t"  <?php if($imovel->churras==true): ?> echo checked=""<?php endif; ?>>
                          <label class="custom-control-label" for="churras">Churrasqueira</label>
                        </div>
                      </div>
                    </div>

                    <div class="control-group form-group row">
                      <div class="custom control custom checkbox mb-3 col-md-6">
                      <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="mobilia" name="mobilia" value="t" <?php if($imovel->mobilia==true): ?> echo checked=""<?php endif; ?>>
                          <label class="custom-control-label" for="mobilia">Mobília</label>
                        </div>
                      </div>
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="aguaq" name="aguaq" value="t"  <?php if($imovel->aguaq==true): ?> echo checked=""<?php endif; ?>>
                          <label class="custom-control-label" for="aguaq">Água Quente</label>
                        </div>
                      </div>
                    </div>

                    <div class="control-group form-group row">
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="cerca" name="cerca" value="t"  <?php if($imovel->cerca==true): ?> echo checked=""<?php endif; ?>>
                          <label class="custom-control-label" for="cerca">Cercado</label>
                        </div>
                      </div>
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="lavanderia" name="lavanderia" value="t"  <?php if($imovel->lavanderia==true): ?> echo checked=""<?php endif; ?>>
                          <label class="custom-control-label" for="lavanderia">Lavanderia</label>
                        </div>
                      </div>
                    </div>

                    <div class="control-group form-group row">
                      <div class="custom control custom checkbox mb-3 col-md-6">
                        <div class="custom-control custom-checkbox">
                          <input type="checkbox" class="custom-control-input" id="quiosque" name="quiosque" value="t"  <?php if($imovel->quiosque==true): ?> echo checked=""<?php endif; ?>>
                          <label class="custom-control-label" for="quiosque">Quiosque</label>
                        </div>
                      </div>
                    </div>

                

            <?php echo $__env->make('layouts.admin.alterar.2geral-alterar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <!-- /.row -->

            </div>
            <!-- /.container -->

            <!-- Footer -->
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <script>
                if($('#jardim').value == 't'){
                    $('#jardim').attr(checked);
                }
            </script>
            <!-- Contact form JavaScript -->
            <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->

          </body>

</html>
