<?php $__env->startSection('1geral-inserir'); ?>
    <h5> Dados Gerais:</h5><br>
            <div class="control-group form-group row">
                  <div class="controls col-md-6">
                    <label for="titulo" class="form-label">Título:</label><br>
                    <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Título do Anúncio">
                  </div>
                  <div class="controls col-md-6">
                    <label for="areatt" class="form-label">Área Total:</label><br>
                    <input type="text" class="form-control" id="areatt" name="areatt"  placeholder="Área Total do Imóvel" onkeypress="if (!isNaN(String.fromCharCode(window.event.keyCode))) return true; else return false;">
                  </div>
                </div>

                <div class="control-group form-group row">
                  <div class="controls col-md-6">
                    <label for="valor" class="form-label">Valor:</label><br>
                    <input type="text" class="form-control" id="valor" name="valor" placeholder="Valor do Imóvel" onkeypress="if (!isNaN(String.fromCharCode(window.event.keyCode))) return true; else return false;">
                  </div>
                  <div class="controls col-md-6">
                    <label for="endereco" class="form-label">Endereço:</label><br>
                    <input type="text" class="form-control" id="endereco" name="endereco" placeholder="Endereço do Imóvel">
                  </div>
                </div>

                <div class="control-group form-group row">
                  <div class="controls col-md-6">
                    <label for="cidade" class="form-label">Cidade:</label><br>
                    <input type="text" class="form-control" id="cidade" name="cidade" placeholder="Cidade do Imóvel">
                  </div>
                  <div class="controls col-md-6">
                    <label for="bairro" class="form-label">Bairro:</label><br>
                    <input type="text" class="form-control" id="bairro" name="bairro" placeholder="Bairro em que se encontra">
                  </div>
                </div>

                <div class="control-group form-group row">
                  <div class="controls col-md-6">
                    <label for="cep" class="form-label">CEP:</label><br>
                    <input type="text" class="form-control" id="cep" name="cep" placeholder="CEP do local">
                  </div>
                  <div class="controls col-md-6">
                    <label for="estado" class="form-label">Estado:</label><br>
                    <input type="text" class="form-control" id="estado" name="estado" placeholder="UF">
                  </div>
                </div>
