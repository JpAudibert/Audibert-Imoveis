
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Terrenos</title>
    <?php echo $__env->make('layouts.site.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <div class="container">
        <?php echo $__env->make('layouts.site.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br />
        <h1 class="mt-4 mb-3">Terrenos</small>
        </h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(url('/')); ?>">Página Inicial</a>
            </li>
            <li class="breadcrumb-item active">Terrenos</li>
        </ol>
        <div class="row">
            <?php $__currentLoopData = $terrenos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terreno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 portfolio-item">
                <div class="card h-100">
                    <a href="<?php echo e(url($terreno['discriminator'].'/ver/mais', Illuminate\Support\Facades\Crypt::encryptString($terreno['id']))); ?>"><img class="card-img-top tamanho-card" src="/images/imovel<?php echo e($terreno->id); ?>/<?php echo e($terreno->img[0]); ?>" alt=""></a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="<?php echo e(url($terreno['discriminator'].'/ver/mais', Illuminate\Support\Facades\Crypt::encryptString($terreno['id']))); ?>"><?php echo e($terreno['titulo']); ?></a>
                        </h4>
                        <p class="card-text"><i class="fas fa-object-group"></i>&nbsp;&nbsp; Terreno</p>
                        <p class="card-text"><i class="fas fa-ruler-combined"></i>&nbsp;&nbsp; <?php echo e($terreno->areatt); ?> m²</p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="centro">
                <?php echo e($terrenos->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.site.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
