
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Comércios</title>
    <?php echo $__env->make('layouts.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <div class="container">
        <?php echo $__env->make('layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br />
        <h1 class="mt-4 mb-3">Comércios</small>
        </h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('home')); ?>">Admin</a>
            </li>
            <li class="breadcrumb-item active">Comércios</li>
        </ol>
        <div class="tabela-listagem"></div>
        <div class="table-responsive">
            <table class="table table-striped mid-field" id="imovel">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Área Total</th>
                        <th>Endereço</th>
                        <th>Valor</th>
                        <th>Cidade</th>
                        <th>Ação 1</th>
                        <th>Ação 2</th>
                        <th>Ação 3</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $imovels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imovel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($imovel['id']); ?> </td>
                        <td><?php echo e($imovel['titulo']); ?></td>
                        <td><?php echo e($imovel['areatt']); ?> m²</td>
                        <td><?php echo e($imovel['endereco']); ?></td>
                        <td id="valor"><?php echo e($imovel['valor']); ?></td>
                        <td><?php echo e($imovel['cidade']); ?></td>
                        <td><a href="<?php echo e(url($imovel['discriminator'].'/ver', Illuminate\Support\Facades\Crypt::encryptString($imovel['id']))); ?>" class="btn btn-success">Ver Mais</a></td>
                        <td><a href="<?php echo e(url($imovel['discriminator'].'/alterar', Illuminate\Support\Facades\Crypt::encryptString($imovel['id']))); ?>" class="btn btn-warning">Alterar</a></td>
                        <td>
                            <form action="<?php echo e(action('ImovelController@destroy', $imovel['id'])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input name="_method" type="hidden" value="DELETE">
                                <button class="btn btn-danger" type="submit">Excluir</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="tabela-listagem"></div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(document).ready( function () {
        $('#imovel').DataTable();
    } );
</script>
</body>
</html>
