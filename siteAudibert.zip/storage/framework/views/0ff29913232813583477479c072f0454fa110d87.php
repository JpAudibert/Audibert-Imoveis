<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Imóveis</title>
    <link rel="stylesheet" href="/css/app.css">
    <link rel="stylesheet" href="/css/style.css">
  </head>
  <body>
    <div class="container">
        <?php echo $__env->make('layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <br />
     <br><br>
     <h1 class="mt-4 mb-3">Imóveis</small>
     </h1>
     <ol class="breadcrumb">
       <li class="breadcrumb-item">
         <a href="<?php echo e(route('home')); ?>">Admin</a>
       </li>
       <li class="breadcrumb-item active">Imóveis</li>
    </ol>
        <div class="col-md-4 right-select">
            <select class="custom-select">
                <option hidden>Selecione Tipo</option>
                <option value="ap">Apartamento</option>
                <option value="casa">Casa</option>
                <option value="ter">Terreno</option>
                <option value="rural">Rural</option>
                <option value="comer">Comercial</option>
            <select>
        </div>
    <table class="table table-striped mid-field">
    <thead>
      <tr>
        <th>ID</th>
        <th>Título</th>
        <th>Área Total</th>
        <th>Endereço</th>
        <th>Valor</th>
        <th>Cidade</th>
        <th colspan="3">Ações</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $imovels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imovel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td><?php echo e($imovel['id']); ?> </td>
        <td><?php echo e($imovel['titulo']); ?></td>
        <td><?php echo e($imovel['areatt']); ?></td>
        <td><?php echo e($imovel['endereco']); ?></td>
        <td><?php echo e($imovel['valor']); ?></td>
        <td><?php echo e($imovel['cidade']); ?></td>
        <td><a href="<?php echo e(url($imovel['discriminator'].'ver', $imovel['id'])); ?>" class="btn btn-success">Ver Mais</a></td>
        <td><a href="<?php echo e(url($imovel['discriminator'].'alterar', $imovel['id'])); ?>" class="btn btn-warning">Alterar</a></td>
        <td>
          <form action="<?php echo e(action('ImovelController@destroy', $imovel['id'])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input name="_method" type="hidden" value="DELETE">
            <button class="btn btn-danger" type="submit">Excluir</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <div class="col-md-12">
</div>
  </div>

  <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>
</html>
