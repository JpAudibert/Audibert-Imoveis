
        <!-- Navigation -->

                <nav class="navbar fixed-top navbar-expand-lg navbar-dark fixed-top cor-audibert">
                  <div class="container">
                    <a class="navbar-brand" href="index.html">Página Inicial</a>
                    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                      <ul class="navbar-nav ml-auto">
                          <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownInserir" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Inserir
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownInserir">
                              <a class="dropdown-item" href="#">Apartamento</a>
                              <a class="dropdown-item" href="#">Casa</a>
                              <a class="dropdown-item" href="imovels/terrenolistar">Terreno</a>
                              <a class="dropdown-item" href="#">Área Rural</a>
                              <a class="dropdown-item" href="#">Salas/Pavilhões</a>
                            </div>
                          </li>
                        <li class="nav-item">
                          <a class="nav-link" href="about.html">Alterar</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="services.html">Excluir</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="<?php echo e(url('imovels')); ?>">Visualizar</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="contact.html">Sair</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </nav>
