<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('layouts.site.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <title>Audibert Imóveis</title>
</head>
<body>
    <?php echo $__env->make('layouts.site.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.site.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container">
        <h2 class="abaixa abaixa-muito">Destaques:</h2>
        <div class="row">
            <?php ($i=0); ?>
            <?php $__currentLoopData = $vendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($i++); ?>
            <div class="col-lg-4 col-sm-6 portfolio-item">
                <div class="card h-100">
                    <a href="<?php echo e(url($venda['discriminator'].'/ver/mais', Illuminate\Support\Facades\Crypt::encryptString($venda['id']))); ?>"><img class="card-img-top tamanho-inicial" src="/images/imovel<?php echo e($venda->id); ?>/<?php echo e($venda->img[0]); ?>" alt=""></a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="<?php echo e(url($venda['discriminator'].'/ver/mais', Illuminate\Support\Facades\Crypt::encryptString($venda['id']))); ?>"><?php echo e($venda['titulo']); ?></a>
                        </h4>
                        <p class="card-text">
                            <?php switch($venda->discriminator):
                            case ("apartamento"): ?>
                            <p class="card-text"><i class="fas fa-building"></i>&nbsp;&nbsp; Apartamento</p>
                            <p class="card-text"><i class="fas fa-ruler-combined"></i>&nbsp;&nbsp; <?php echo e($venda->areatt); ?> m²</p>
                            <p class="card-text"><i class="fas fa-bed"></i>&nbsp;&nbsp; <?php if($venda->quartos==1): ?> <?php echo e($venda->quartos); ?> quarto <?php else: ?> <?php echo e($venda->quartos); ?> quartos <?php endif; ?></p>
                            <p class="card-text"><i class="fas fa-car"></i>&nbsp;&nbsp; <?php if($venda->garagem==1): ?> <?php echo e($venda->garagem); ?> vaga <?php else: ?> <?php echo e($venda->garagem); ?> vagas <?php endif; ?></p>
                            <p class="card-text"><i class="fas fa-toilet-paper"></i>&nbsp;&nbsp; <?php if($venda->banheiros==1): ?> <?php echo e($venda->banheiros); ?> banheiro <?php else: ?> <?php echo e($venda->banheiros); ?> banheiros <?php endif; ?></p>
                            <?php break; ?>
                            <?php case ("casa"): ?>
                            <p class="card-text"><i class="fas fa-home"></i>&nbsp;&nbsp; Casa</p>
                            <p class="card-text"><i class="fas fa-ruler-combined"></i>&nbsp;&nbsp; <?php echo e($venda->areatt); ?> m²</p>
                            <p class="card-text"><i class="fas fa-bed"></i>&nbsp;&nbsp; <?php if($venda->quartos==1): ?> <?php echo e($venda->quartos); ?> quarto <?php else: ?> <?php echo e($venda->quartos); ?> quartos <?php endif; ?></p>
                            <p class="card-text"><i class="fas fa-car"></i>&nbsp;&nbsp; <?php if($venda->garagem==1): ?> <?php echo e($venda->garagem); ?> vaga <?php else: ?> <?php echo e($venda->garagem); ?> vagas <?php endif; ?></p>
                            <p class="card-text"><i class="fas fa-toilet-paper"></i>&nbsp;&nbsp; <?php if($venda->banheiros==1): ?> <?php echo e($venda->banheiros); ?> banheiro <?php else: ?> <?php echo e($venda->banheiros); ?> banheiros <?php endif; ?></p>
                            <?php break; ?>
                            <?php case ("comercial"): ?>
                            <p class="card-text"><?php if($venda->categoria=="1"): ?><i class="fas fa-store"></i> &nbsp;&nbsp;Sala Comercial <?php else: ?> <i class="fas fa-industry"></i> &nbsp;&nbsp;Pavilhão Industrial <?php endif; ?></p>
                            <p class="card-text"><i class="fas fa-ruler-combined"></i>&nbsp;&nbsp; <?php echo e($venda->areatt); ?> m²</p>
                            <?php break; ?>
                            <?php case ("rural"): ?>
                            <p class="card-text"><i class="fas fa-horse"></i>&nbsp;&nbsp; Área Rural</p>
                            <p class="card-text"><i class="fas fa-ruler-combined"></i>&nbsp;&nbsp; <?php echo e($venda->areatt); ?> m²</p>
                            <p class="card-text"><i class="fas fa-vector-square"></i>&nbsp;&nbsp; <?php if($venda->cerca=="t"): ?> Cercado <?php endif; ?></p>
                            <p class="card-text"><i class="fas fa-bolt"></i>&nbsp;&nbsp; <?php if($venda->energia=="t"): ?> Com Acesso a Energia Elétrica <?php endif; ?></p>
                            <?php break; ?>
                            <?php case ("terreno"): ?>
                            <p class="card-text"><i class="fas fa-object-group"></i>&nbsp;&nbsp; Terreno</p>
                            <p class="card-text"><i class="fas fa-ruler-combined"></i>&nbsp;&nbsp; <?php echo e($venda->areatt); ?> m²</p>
                            <?php break; ?>
                            <?php default: ?>
                            Erro
                            <?php endswitch; ?>
                        </p>
                    </div>
                </div>
            </div>
            <?php if($i==6): ?>
            <?php break; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.site.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="/js/bootstrap.bundle.min.js">
</body>
</html>
