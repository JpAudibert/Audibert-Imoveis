
<html lang="en">

<head>
    <?php echo $__env->make('\layouts.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Mostrar Imóvel</title>
</head>
<body>
    <div class="container">
        <?php echo $__env->make('\layouts.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3"><?php echo e($imovel->titulo); ?>

        </h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('home')); ?>">Admin</a>
            </li>
            <li class="breadcrumb-item active">Mostrar Casa</li>
        </ol>
        <!-- Content Row -->
        <div class="row">
            <div class="container">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <?php for($i = 1; $i < count($imovel->img); $i++): ?>
                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($i); ?>"></li>
                        <?php endfor; ?>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100 fit" src="/images/imovel<?php echo e($imovel->id); ?>/<?php echo e($imovel->img[0]); ?>">
                        </div>
                        <?php for($j = 1; $j < count($imovel->img); $j++): ?>
                        <div class="carousel-item">
                            <img class="d-block w-100 fit" src="/images/imovel<?php echo e($imovel->id); ?>/<?php echo e($imovel->img[$j]); ?>">
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <div class="listagem-imovel box">
                <div class="alinha-texto">
                    <i class="fas fa-map-pin"></i>&nbsp;&nbsp;Endereço: <?php echo e($imovel->endereco); ?>, <?php echo e($imovel->bairro); ?>, <?php echo e($imovel->cidade); ?>, <?php echo e($imovel->estado); ?> - <?php echo e($imovel->cep); ?> - &nbsp;&nbsp;<i class="fas fa-money-bill-wave"></i> Valor: <?php echo e($imovel->valor); ?>

                </div>
                <div class="alinha-texto">
                    <i class="fas fa-ruler-combined"></i>&nbsp;&nbsp;Área do Terreno: <?php echo e($imovel->areatt); ?> m² -
                    &nbsp;&nbsp;<i class="fas fa-car"></i>&nbsp;&nbsp;Vagas de Garagem: <?php if($imovel->garagem=="0"): ?>
                    Sem garagem
                    <?php else: ?>
                    <?php if($imovel->garagem=='4'): ?>
                    <?php echo e($imovel->garagem); ?> ou mais vagas
                    <?php else: ?>
                    <?php echo e($imovel->garagem); ?> vagas
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="alinha-texto">
                    &nbsp;&nbsp;<i class="fas fa-bed"></i> Dormitórios: <?php if($imovel->quartos=="1"): ?>
                    <?php echo e($imovel->quartos); ?> quarto -
                    <?php else: ?>
                    <?php if($imovel->quartos=='4'): ?>
                    <?php echo e($imovel->quartos); ?> ou mais quartos -
                    <?php else: ?>
                    <?php echo e($imovel->quartos); ?> quartos -
                    <?php endif; ?>
                    <?php endif; ?>
                    &nbsp;&nbsp;<i class="fas fa-toilet-paper"></i> Banheiros: <?php if($imovel->banheiros=="1"): ?>
                    <?php echo e($imovel->banheiros); ?> banheiro
                    <?php else: ?>
                    <?php if($imovel->banheiros=='4'): ?>
                    <?php echo e($imovel->banheiros); ?> ou mais banheiros
                    <?php else: ?>
                    <?php echo e($imovel->banheiros); ?> banheiros
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="dados">
                <h4 class="titulo-descricao">Descrição do imovel:</h4>
                <div class="descricao">
                    <p><?php echo e($imovel->obs); ?></p>
                    <br>
                    <h5>Notas:</h5>
                    <?php if($imovel->nome_prop!==null): ?> <p><strong> Nome do Proprietário:</strong> <?php echo e($imovel->nome_prop); ?></p> <?php endif; ?>
                    <?php if($imovel->matricula!==null): ?> <p><strong> Matrícula do imóvel:</strong> <?php echo e($imovel->matricula); ?></p> <?php endif; ?>
                    <?php if($imovel->telefone_prop!==null && $imovel->celular_prop!==null): ?> <p><strong> Telefones:</strong> <?php echo e($imovel->telefone_prop); ?> - <?php echo e($imovel->celular_prop); ?></p><?php endif; ?>
                    <?php if($imovel->telefone_prop!==null && $imovel->celular_prop==null): ?> <p><strong> Telefone:</strong> <?php echo e($imovel->telefone_prop); ?></p><?php endif; ?>
                    <?php if($imovel->telefone_prop==null && $imovel->celular_prop!==null): ?> <p><strong> Telefone:</strong> <?php echo e($imovel->celular_prop); ?></p><?php endif; ?>
                    <?php if($imovel->valor!==null): ?> <p><strong> Valor do Imóvel:</strong> R$ <?php echo e($imovel->valor_real); ?></p><?php endif; ?>
                    <?php if($imovel->notas==null): ?>
                    Não há anotações.
                    <?php else: ?>
                    <p><?php echo e($imovel->notas); ?></p>
                    <?php endif; ?>
                </div>
                <div class="dados-mais">
                    <p><i class="fas fa-ruler-combined green"></i>&nbsp;&nbsp; Área da Casa: <?php echo e($imovel->areapv); ?> m² </p>
                    <?php if($imovel->jardim!=="t"): ?><p  class="nao-mostra"><i class="far fa-check-square green"></i> Jardim</p> <?php else: ?> <p><i class="far fa-check-square green"></i>&nbsp;&nbsp; Jardim </p> <?php endif; ?>
                    <?php if($imovel->churras!=="t"): ?><p  class="nao-mostra"><i class="far fa-check-square green"></i> Churrasqueira</p>  <?php else: ?> <p><i class="far fa-check-square green"></i>&nbsp;&nbsp; Churrasqueira</p> <?php endif; ?>
                    <?php if($imovel->mobilia!=="t"): ?><p  class="nao-mostra"><i class="far fa-check-square green"></i> Mobília</p> <?php else: ?> <p><i class="far fa-check-square green"></i>&nbsp;&nbsp; Mobília</p> <?php endif; ?>
                    <?php if($imovel->aguaq!=="t"): ?><p  class="nao-mostra"><i class="far fa-check-square green"></i> Água Quente </p> <?php else: ?> <p><i class="far fa-check-square green"></i>&nbsp;&nbsp; Água Quente</p> <?php endif; ?>
                    <?php if($imovel->cerca!=="t"): ?><p  class="nao-mostra"><i class="far fa-check-square green"></i> Cercado </p> <?php else: ?> <p><i class="far fa-check-square green"></i>&nbsp;&nbsp; Cercado</p> <?php endif; ?>
                    <?php if($imovel->lavandeira!=="t"): ?><p  class="nao-mostra"><i class="far fa-check-square green"></i> Lavanderia</p> <?php else: ?> <p><i class="far fa-check-square green"></i>&nbsp;&nbsp; Lavanderia</p> <?php endif; ?>
                    <?php if($imovel->quiosque!=="t"): ?><p  class="nao-mostra"><i class="far fa-check-square green"></i> Quiosque </p> <?php else: ?> <p><i class="far fa-check-square green"></i>&nbsp;&nbsp; Quiosque </p> <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
    <?php echo $__env->make('\layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('\layouts.admin.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

</html>
