<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php echo $__env->make('layouts.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Alterar Imóvel</title>
  </head>
  <body>

        <!-- Navigation -->
        <div class="container">
        <?php echo $__env->make('layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Inserir Terreno</small>
          </h1>

          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.html">Admin</a>
            </li>
            <li class="breadcrumb-item active">Inserir Terreno</li>
          </ol>
            <!-- Content Row -->
          <div class="row">
            <!-- Sidebar Column -->
            <div class="col-lg-3 mb-4">
              <div class="list-group">
                <a href="#" class="list-group-item">Apartamento</a>
                <a href="#" class="list-group-item">Casa</a>
                <a href="#" class="list-group-item active">Terreno</a>
                <a href="#" class="list-group-item">Área Rural</a>
                <a href="#" class="list-group-item">Salas/Pavilhões</a>
                <a href="#" class="list-group-item">Sair</a>
              </div>
            </div>
            <!-- Content Column -->
            <div class="col-lg-9 mb-4">
              <form name="inserir_ter" id="inserir_ter" action="<?php echo e(route('update')); ?>" method="POST" multipart="form/data">
                <?php echo csrf_field(); ?>
                <h3>Terreno</h3>
            <?php echo $__env->make('layouts.admin.alterar.1geral-alterar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.admin.alterar.2geral-alterar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <!-- /.row -->

            </div>
            <!-- /.container -->

            <!-- Footer -->
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

            <!-- Contact form JavaScript -->
            <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->

          </body>

</html>
