<!DOCTYPE html>
<html lang="en">

  <head>
    <?php echo $__env->make('\layouts.admin.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>Inserir Terreno</title>
  </head>
  <body>
    <div class="container">
<?php echo $__env->make('\layouts.admin.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Heading/Breadcrumbs -->
<h1 class="mt-4 mb-3">Inserir Terreno</small>
</h1>

<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="index.html">Admin</a>f
    </li>
    <li class="breadcrumb-item active">Inserir Terreno</li>
</ol>
<!-- Content Row -->
<div class="row">
    <!-- Sidebar Column -->
    <div class="col-lg-3 mb-4">
        <div class="list-group">
            <a href="#" class="list-group-item">Apartamento</a>
            <a href="#" class="list-group-item">Casa</a>
            <a href="#" class="list-group-item active">Terreno</a>
            <a href="#" class="list-group-item">Área Rural</a>
            <a href="#" class="list-group-item">Salas/Pavilhões</a>
            <a href="#" class="list-group-item">Sair</a>
        </div>
    </div>
    <!-- Content Column -->
    <div class="col-lg-9 mb-4">
        <form name="inserir_ter" id="inserir_ter" action="<?php echo e(route('store')); ?>" method="POST" multipart="form/data">
            <?php echo csrf_field(); ?>
            
            <input type="hidden" name="discriminator" id="discriminator" value="terreno">
            

            <div class="container">
                <h3>Terreno</h3>
                <?php echo $__env->make('\layouts.admin.inserir.1geral-inserir', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('\layouts.admin.inserir.2geral-inserir', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

              <!-- /.row -->

            </div>
            <!-- /.container -->
                <?php echo $__env->make('\layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('\layouts.admin.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Contact form JavaScript -->
            <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->

          </body>

</html>
